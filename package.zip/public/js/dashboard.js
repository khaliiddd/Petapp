// Dashboard specific functionality
let currentUser = null;
let currentTab = 'overview';
let myEquipment = [];
let myBookings = [];
let myRentals = [];

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
});

async function initializeDashboard() {
    try {
        // Check if user is logged in
        const userResponse = await apiRequest('/api/me');
        currentUser = userResponse.user;
        
        if (!currentUser) {
            window.location.href = '/index.html';
            return;
        }

        updateWelcomeMessage();
        setupDashboardEventListeners();
        showTab('overview');
        loadDashboardData();
        
    } catch (error) {
        console.error('Failed to initialize dashboard:', error);
        window.location.href = '/index.html';
    }
}

function updateWelcomeMessage() {
    const welcomeEl = document.getElementById('welcome-message');
    const userNameEl = document.getElementById('user-name');
    
    if (welcomeEl) {
        welcomeEl.textContent = `Welcome back, ${currentUser.firstName || currentUser.username}!`;
    }
    
    if (userNameEl) {
        userNameEl.textContent = `Hello, ${currentUser.firstName || currentUser.username}`;
    }

    // Show/hide relevant tabs based on user type
    const myEquipmentTab = document.getElementById('my-equipment-tab');
    const addEquipmentTab = document.getElementById('add-equipment-tab');
    const addEquipmentBtn = document.getElementById('add-equipment-btn');

    if (currentUser.userType === 'owner' || currentUser.userType === 'both') {
        if (myEquipmentTab) myEquipmentTab.style.display = 'block';
        if (addEquipmentTab) addEquipmentTab.style.display = 'block';
        if (addEquipmentBtn) addEquipmentBtn.style.display = 'flex';
    }
}

function setupDashboardEventListeners() {
    // Tab navigation
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const tab = btn.getAttribute('data-tab');
            showTab(tab);
        });
    });

    // Booking status filters
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const status = btn.getAttribute('data-status');
            filterBookings(status);
        });
    });

    // Equipment form
    const addEquipmentForm = document.getElementById('add-equipment-form');
    if (addEquipmentForm) {
        addEquipmentForm.addEventListener('submit', handleAddEquipment);
    }

    // Edit equipment form
    const editEquipmentForm = document.getElementById('edit-equipment-form');
    if (editEquipmentForm) {
        editEquipmentForm.addEventListener('submit', handleEditEquipment);
    }

    // Close modals
    document.querySelectorAll('.close').forEach(closeBtn => {
        closeBtn.addEventListener('click', (e) => {
            const modal = e.target.closest('.modal');
            if (modal) {
                modal.style.display = 'none';
            }
        });
    });

    // Logout
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
}

async function loadDashboardData() {
    try {
        // Load user's equipment
        if (currentUser.userType === 'owner' || currentUser.userType === 'both') {
            const equipmentResponse = await apiRequest('/api/my-equipment');
            myEquipment = equipmentResponse.equipment || [];
            displayMyEquipment();
        }

        // Load bookings (as owner)
        const bookingsResponse = await apiRequest('/api/bookings?role=owner');
        myBookings = bookingsResponse.bookings || [];
        displayMyBookings();

        // Load rentals (as renter)
        const rentalsResponse = await apiRequest('/api/bookings?role=renter');
        myRentals = rentalsResponse.bookings || [];
        displayMyRentals();

        // Update overview stats
        updateOverviewStats();

    } catch (error) {
        console.error('Failed to load dashboard data:', error);
        showMessage('Failed to load dashboard data', 'error');
    }
}

function updateOverviewStats() {
    const totalEquipmentEl = document.getElementById('total-equipment');
    const totalBookingsEl = document.getElementById('total-bookings');
    const totalRevenueEl = document.getElementById('total-revenue');
    const ratingEl = document.getElementById('rating');

    if (totalEquipmentEl) totalEquipmentEl.textContent = myEquipment.length;
    if (totalBookingsEl) totalBookingsEl.textContent = myBookings.length + myRentals.length;

    // Calculate revenue from approved/completed bookings
    const revenueBookings = myBookings.filter(booking => 
        booking.status === 'approved' || booking.status === 'completed'
    );
    const totalRevenue = revenueBookings.reduce((sum, booking) => sum + (booking.totalAmount || 0), 0);
    if (totalRevenueEl) totalRevenueEl.textContent = `$${totalRevenue.toFixed(2)}`;

    // Mock rating (in real app, calculate from reviews)
    if (ratingEl) ratingEl.textContent = '4.8';
}

function showTab(tabName) {
    // Update nav buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.getAttribute('data-tab') === tabName) {
            btn.classList.add('active');
        }
    });

    // Update tab content
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    const targetTab = document.getElementById(tabName);
    if (targetTab) {
        targetTab.classList.add('active');
    }

    currentTab = tabName;
}

function displayMyEquipment() {
    const equipmentGrid = document.getElementById('my-equipment-grid');
    if (!equipmentGrid) return;

    if (myEquipment.length === 0) {
        equipmentGrid.innerHTML = `
            <div class="empty-state" style="grid-column: 1 / -1;">
                <i class="fas fa-tools"></i>
                <h3>No Equipment Listed</h3>
                <p>Start earning by listing your pet equipment for rent.</p>
                <button class="btn btn-primary" onclick="showAddEquipmentModal()">
                    <i class="fas fa-plus"></i> List Your First Equipment
                </button>
            </div>
        `;
        return;
    }

    equipmentGrid.innerHTML = '';
    
    myEquipment.forEach(item => {
        const card = createMyEquipmentCard(item);
        equipmentGrid.appendChild(card);
    });
}

function createMyEquipmentCard(item) {
    const card = document.createElement('div');
    card.className = 'dashboard-equipment-card';
    
    const icon = getCategoryIcon(item.category);
    const statusClass = item.available ? 'status-available' : 'status-unavailable';
    const statusText = item.available ? 'Available' : 'Unavailable';
    
    card.innerHTML = `
        <div class="dashboard-equipment-header">
            <div class="dashboard-equipment-icon">
                <i class="${icon}"></i>
            </div>
            <div class="dashboard-equipment-info">
                <h3>${item.title}</h3>
                <p>${item.location} • ${item.category}</p>
                <span class="dashboard-equipment-status ${statusClass}">${statusText}</span>
            </div>
        </div>
        <div class="dashboard-equipment-body">
            <p class="dashboard-equipment-description">${item.description || 'No description provided'}</p>
            <div class="dashboard-equipment-details">
                <div class="dashboard-equipment-detail">
                    <strong>$${item.dailyRate}</strong>
                    <span>per day</span>
                </div>
                ${item.weeklyRate ? `
                <div class="dashboard-equipment-detail">
                    <strong>$${item.weeklyRate}</strong>
                    <span>per week</span>
                </div>
                ` : ''}
                <div class="dashboard-equipment-detail">
                    <strong>$${item.deposit || 0}</strong>
                    <span>deposit</span>
                </div>
                <div class="dashboard-equipment-detail">
                    <strong>${item.pickupMethod}</strong>
                    <span>pickup</span>
                </div>
            </div>
            <div class="dashboard-equipment-actions">
                <button class="btn btn-primary" onclick="editEquipment(${item.id})">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button class="btn ${item.available ? 'btn-secondary' : 'btn-success'}" onclick="toggleEquipmentAvailability(${item.id}, ${!item.available})">
                    <i class="fas fa-${item.available ? 'eye-slash' : 'eye'}"></i> ${item.available ? 'Make Unavailable' : 'Make Available'}
                </button>
                <button class="btn btn-danger" onclick="deleteEquipment(${item.id})">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        </div>
    `;
    
    return card;
}

function displayMyBookings() {
    const bookingsList = document.getElementById('bookings-list');
    if (!bookingsList) return;

    if (myBookings.length === 0) {
        bookingsList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-calendar-check"></i>
                <h3>No Bookings Yet</h3>
                <p>Your equipment hasn't been booked yet. Share your listings to get more visibility.</p>
            </div>
        `;
        return;
    }

    bookingsList.innerHTML = '';
    myBookings.forEach(booking => {
        const bookingItem = createBookingItem(booking);
        bookingsList.appendChild(bookingItem);
    });
}

function displayMyRentals() {
    const rentalsList = document.getElementById('rentals-list');
    if (!rentalsList) return;

    if (myRentals.length === 0) {
        rentalsList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-handshake"></i>
                <h3>No Active Rentals</h3>
                <p>You haven't rented any equipment yet. Browse our marketplace to get started.</p>
                <button class="btn btn-primary" onclick="window.location.href='/index.html#browse'">
                    <i class="fas fa-search"></i> Browse Equipment
                </button>
            </div>
        `;
        return;
    }

    rentalsList.innerHTML = '';
    myRentals.forEach(rental => {
        const rentalItem = createBookingItem(rental);
        rentalsList.appendChild(rentalItem);
    });
}

function createBookingItem(booking) {
    const item = document.createElement('div');
    item.className = `booking-item ${booking.status}`;
    
    const statusClass = `status-${booking.status}`;
    const statusText = booking.status.charAt(0).toUpperCase() + booking.status.slice(1);
    
    item.innerHTML = `
        <div class="booking-header">
            <div class="booking-info">
                <h3>${booking.title}</h3>
                <p><i class="fas fa-user"></i> ${booking.status === 'pending' ? 'Renter' : 'Renter'}: ${booking.renterFirstName} ${booking.renterLastName}</p>
                <p><i class="fas fa-calendar"></i> ${formatDate(booking.startDate)} - ${formatDate(booking.endDate)}</p>
                <p><i class="fas fa-map-marker-alt"></i> ${booking.equipmentLocation}</p>
            </div>
            <span class="booking-status ${statusClass}">${statusText}</span>
        </div>
        <div class="booking-details">
            <div class="booking-detail">
                <strong>${booking.totalDays}</strong>
                <span>days</span>
            </div>
            <div class="booking-detail">
                <strong>$${booking.dailyRate}/day</strong>
                <span>daily rate</span>
            </div>
            <div class="booking-detail">
                <strong>$${booking.totalAmount}</strong>
                <span>total amount</span>
            </div>
            <div class="booking-detail">
                <strong>$${booking.depositAmount || 0}</strong>
                <span>deposit</span>
            </div>
        </div>
        ${booking.message ? `
        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
            <strong>Message:</strong>
            <p style="margin: 5px 0 0 0; color: #666;">${booking.message}</p>
        </div>
        ` : ''}
        <div class="booking-actions">
            ${getBookingActions(booking)}
        </div>
    `;
    
    return item;
}

function getBookingActions(booking) {
    if (currentUser.id === booking.ownerId) {
        // Owner actions
        if (booking.status === 'pending') {
            return `
                <button class="btn btn-success" onclick="updateBookingStatus(${booking.id}, 'approved')">
                    <i class="fas fa-check"></i> Approve
                </button>
                <button class="btn btn-danger" onclick="updateBookingStatus(${booking.id}, 'rejected')">
                    <i class="fas fa-times"></i> Reject
                </button>
            `;
        } else if (booking.status === 'approved') {
            return `
                <button class="btn btn-secondary" onclick="updateBookingStatus(${booking.id}, 'completed')">
                    <i class="fas fa-check-double"></i> Mark Complete
                </button>
            `;
        }
    } else {
        // Renter actions
        if (booking.status === 'pending') {
            return `
                <button class="btn btn-secondary" onclick="updateBookingStatus(${booking.id}, 'cancelled')">
                    <i class="fas fa-times"></i> Cancel Request
                </button>
            `;
        } else if (booking.status === 'approved') {
            return `
                <button class="btn btn-secondary" onclick="updateBookingStatus(${booking.id}, 'cancelled')">
                    <i class="fas fa-times"></i> Cancel Booking
                </button>
            `;
        }
    }
    
    return '<span style="color: #666; font-style: italic;">No actions available</span>';
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function filterBookings(status) {
    const filteredBookings = status === 'all' ? myBookings : myBookings.filter(booking => booking.status === status);
    const bookingsList = document.getElementById('bookings-list');
    
    if (filteredBookings.length === 0) {
        bookingsList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-calendar"></i>
                <h3>No ${status} bookings</h3>
                <p>There are no bookings with ${status} status.</p>
            </div>
        `;
        return;
    }

    bookingsList.innerHTML = '';
    filteredBookings.forEach(booking => {
        const bookingItem = createBookingItem(booking);
        bookingsList.appendChild(bookingItem);
    });
}

// Equipment management functions
async function handleAddEquipment(e) {
    e.preventDefault();
    
    const formData = {
        title: document.getElementById('eq-title').value,
        category: document.getElementById('eq-category').value,
        subcategory: document.getElementById('eq-subcategory').value,
        brand: document.getElementById('eq-brand').value,
        description: document.getElementById('eq-description').value,
        condition: document.getElementById('eq-condition').value,
        location: document.getElementById('eq-location').value,
        dailyRate: parseFloat(document.getElementById('eq-daily-rate').value),
        weeklyRate: document.getElementById('eq-weekly-rate').value ? parseFloat(document.getElementById('eq-weekly-rate').value) : null,
        monthlyRate: document.getElementById('eq-monthly-rate').value ? parseFloat(document.getElementById('eq-monthly-rate').value) : null,
        deposit: parseFloat(document.getElementById('eq-deposit').value) || 0,
        deliveryFee: parseFloat(document.getElementById('eq-delivery-fee').value) || 0,
        pickupMethod: document.getElementById('eq-pickup-method').value,
        minimumRentalDays: parseInt(document.getElementById('eq-min-days').value) || 1,
        maximumRentalDays: document.getElementById('eq-max-days').value ? parseInt(document.getElementById('eq-max-days').value) : null
    };

    try {
        await apiRequest('/api/equipment', {
            method: 'POST',
            body: JSON.stringify(formData)
        });

        showMessage('Equipment listed successfully!', 'success');
        clearEquipmentForm();
        loadDashboardData(); // Reload data
        showTab('my-equipment');
        
    } catch (error) {
        // Error already shown in apiRequest
    }
}

function clearEquipmentForm() {
    document.getElementById('add-equipment-form').reset();
}

function showAddEquipmentModal() {
    showTab('add-equipment');
}

async function editEquipment(equipmentId) {
    const equipment = myEquipment.find(eq => eq.id === equipmentId);
    if (!equipment) return;

    // Populate edit form
    document.getElementById('edit-equipment-id').value = equipment.id;
    document.getElementById('edit-eq-title').value = equipment.title;
    document.getElementById('edit-eq-category').value = equipment.category;
    document.getElementById('edit-eq-description').value = equipment.description || '';
    document.getElementById('edit-eq-daily-rate').value = equipment.dailyRate;
    document.getElementById('edit-eq-available').value = equipment.available ? '1' : '0';

    document.getElementById('edit-equipment-modal').style.display = 'block';
}

async function handleEditEquipment(e) {
    e.preventDefault();
    
    const equipmentId = document.getElementById('edit-equipment-id').value;
    const formData = {
        title: document.getElementById('edit-eq-title').value,
        category: document.getElementById('edit-eq-category').value,
        description: document.getElementById('edit-eq-description').value,
        dailyRate: parseFloat(document.getElementById('edit-eq-daily-rate').value),
        available: document.getElementById('edit-eq-available').value === '1'
    };

    try {
        await apiRequest(`/api/equipment/${equipmentId}`, {
            method: 'PUT',
            body: JSON.stringify(formData)
        });

        showMessage('Equipment updated successfully!', 'success');
        closeModal('edit-equipment-modal');
        loadDashboardData(); // Reload data
        
    } catch (error) {
        // Error already shown in apiRequest
    }
}

async function toggleEquipmentAvailability(equipmentId, available) {
    try {
        await apiRequest(`/api/equipment/${equipmentId}`, {
            method: 'PUT',
            body: JSON.stringify({ available })
        });

        showMessage(`Equipment ${available ? 'made available' : 'made unavailable'}`, 'success');
        loadDashboardData(); // Reload data
        
    } catch (error) {
        // Error already shown in apiRequest
    }
}

async function deleteEquipment(equipmentId) {
    if (!confirm('Are you sure you want to delete this equipment? This action cannot be undone.')) {
        return;
    }

    try {
        await apiRequest(`/api/equipment/${equipmentId}`, {
            method: 'DELETE'
        });

        showMessage('Equipment deleted successfully', 'success');
        loadDashboardData(); // Reload data
        
    } catch (error) {
        // Error already shown in apiRequest
    }
}

async function updateBookingStatus(bookingId, status) {
    try {
        await apiRequest(`/api/bookings/${bookingId}/status`, {
            method: 'PUT',
            body: JSON.stringify({ status })
        });

        const actionText = {
            'approved': 'approved',
            'rejected': 'rejected', 
            'completed': 'completed',
            'cancelled': 'cancelled'
        }[status];

        showMessage(`Booking ${actionText} successfully`, 'success');
        loadDashboardData(); // Reload data
        
    } catch (error) {
        // Error already shown in apiRequest
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}

function getCategoryIcon(category) {
    const icons = {
        'Grooming': 'fas fa-cut',
        'Training': 'fas fa-graduation-cap',
        'Health': 'fas fa-heartbeat',
        'Travel': 'fas fa-car',
        'Safety': 'fas fa-shield-alt'
    };
    return icons[category] || 'fas fa-paw';
}

// Message system (inherits from app.js)
function showMessage(message, type = 'info') {
    const container = document.getElementById('message-container');
    if (!container) return;

    const messageEl = document.createElement('div');
    messageEl.className = `message ${type}`;
    messageEl.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
            <i class="fas fa-${getMessageIcon(type)}"></i>
            <span>${message}</span>
            <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; color: inherit; margin-left: auto; cursor: pointer;">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;

    container.appendChild(messageEl);

    // Auto remove after 5 seconds
    setTimeout(() => {
        if (messageEl.parentNode) {
            messageEl.remove();
        }
    }, 5000);
}

function getMessageIcon(type) {
    const icons = {
        'success': 'check-circle',
        'error': 'exclamation-circle',
        'info': 'info-circle',
        'warning': 'exclamation-triangle'
    };
    return icons[type] || 'info-circle';
}