// Global state
let currentUser = null;
let currentEquipment = null;
let currentBookingEquipment = null;

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    loadCurrentUser();
    setupEventListeners();
    loadEquipment();
});

// Event Listeners Setup
function setupEventListeners() {
    // Navigation
    const mobileMenu = document.getElementById('mobile-menu');
    const navMenu = document.getElementById('nav-menu');
    
    if (mobileMenu) {
        mobileMenu.addEventListener('click', () => {
            navMenu.classList.toggle('active');
        });
    }

    // Modal handlers
    setupModalHandlers();
    
    // Form handlers
    setupFormHandlers();
    
    // Search and filter
    setupSearchHandlers();
    
    // Close modals when clicking outside
    window.addEventListener('click', (event) => {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    });
}

function setupModalHandlers() {
    // Login/Register modal switching
    const loginBtn = document.getElementById('login-btn');
    const registerBtn = document.getElementById('register-btn');
    const loginModal = document.getElementById('login-modal');
    const registerModal = document.getElementById('register-modal');
    const switchToRegister = document.getElementById('switch-to-register');
    const switchToLogin = document.getElementById('switch-to-login');

    if (loginBtn) {
        loginBtn.addEventListener('click', (e) => {
            e.preventDefault();
            loginModal.style.display = 'block';
        });
    }

    if (registerBtn) {
        registerBtn.addEventListener('click', (e) => {
            e.preventDefault();
            registerModal.style.display = 'block';
        });
    }

    if (switchToRegister) {
        switchToRegister.addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('login-modal').style.display = 'none';
            document.getElementById('register-modal').style.display = 'block';
        });
    }

    if (switchToLogin) {
        switchToLogin.addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('register-modal').style.display = 'none';
            document.getElementById('login-modal').style.display = 'block';
        });
    }

    // Close buttons
    document.querySelectorAll('.close').forEach(closeBtn => {
        closeBtn.addEventListener('click', () => {
            document.querySelectorAll('.modal').forEach(modal => {
                modal.style.display = 'none';
            });
        });
    });

    // Logout
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
}

function setupFormHandlers() {
    // Login form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Register form
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }

    // Booking form
    const bookingForm = document.getElementById('booking-form');
    if (bookingForm) {
        bookingForm.addEventListener('submit', handleBooking);
    }
}

function setupSearchHandlers() {
    const searchBtn = document.getElementById('search-btn');
    const searchInput = document.getElementById('search-input');
    const categoryFilter = document.getElementById('category-filter');
    const locationFilter = document.getElementById('location-filter');

    if (searchBtn) {
        searchBtn.addEventListener('click', performSearch);
    }

    if (searchInput) {
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
    }

    if (categoryFilter) {
        categoryFilter.addEventListener('change', performSearch);
    }

    if (locationFilter) {
        locationFilter.addEventListener('change', performSearch);
    }
}

// API Functions
async function apiRequest(endpoint, options = {}) {
    const defaultOptions = {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        },
    };

    const mergedOptions = { ...defaultOptions, ...options };
    
    try {
        const response = await fetch(endpoint, mergedOptions);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Request failed');
        }
        
        return data;
    } catch (error) {
        console.error('API request failed:', error);
        showMessage(error.message, 'error');
        throw error;
    }
}

// Authentication Functions
async function loadCurrentUser() {
    try {
        const response = await apiRequest('/api/me');
        currentUser = response.user;
        updateNavigation();
    } catch (error) {
        console.error('Failed to load user:', error);
    }
}

function updateNavigation() {
    const navAuth = document.getElementById('nav-auth');
    const navUser = document.getElementById('nav-user');
    const userName = document.getElementById('user-name');

    if (currentUser) {
        navAuth.style.display = 'none';
        navUser.style.display = 'flex';
        if (userName) {
            userName.textContent = `Hello, ${currentUser.firstName || currentUser.username}`;
        }
    } else {
        navAuth.style.display = 'flex';
        navUser.style.display = 'none';
    }
}

async function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
        const response = await apiRequest('/api/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });

        currentUser = response.user;
        updateNavigation();
        document.getElementById('login-modal').style.display = 'none';
        showMessage('Login successful!', 'success');
    } catch (error) {
        // Error already shown in apiRequest
    }
}

async function handleRegister(e) {
    e.preventDefault();
    
    const formData = {
        firstName: document.getElementById('reg-firstName').value,
        lastName: document.getElementById('reg-lastName').value,
        username: document.getElementById('reg-username').value,
        email: document.getElementById('reg-email').value,
        password: document.getElementById('reg-password').value,
        location: document.getElementById('reg-location').value,
        userType: document.getElementById('reg-userType').value
    };

    try {
        const response = await apiRequest('/api/register', {
            method: 'POST',
            body: JSON.stringify(formData)
        });

        currentUser = response.user;
        updateNavigation();
        document.getElementById('register-modal').style.display = 'none';
        showMessage('Account created successfully!', 'success');
    } catch (error) {
        // Error already shown in apiRequest
    }
}

async function handleLogout(e) {
    e.preventDefault();
    
    try {
        await apiRequest('/api/logout', { method: 'POST' });
        currentUser = null;
        updateNavigation();
        showMessage('Logged out successfully', 'info');
    } catch (error) {
        console.error('Logout failed:', error);
    }
}

// Equipment Functions
async function loadEquipment() {
    try {
        const params = new URLSearchParams();
        const search = document.getElementById('search-input')?.value;
        const category = document.getElementById('category-filter')?.value;
        const location = document.getElementById('location-filter')?.value;

        if (search) params.append('search', search);
        if (category) params.append('category', category);
        if (location) params.append('location', location);

        const queryString = params.toString();
        const endpoint = '/api/equipment' + (queryString ? '?' + queryString : '');
        
        const response = await apiRequest(endpoint);
        displayEquipment(response.equipment);
    } catch (error) {
        console.error('Failed to load equipment:', error);
    }
}

function displayEquipment(equipment) {
    const equipmentGrid = document.getElementById('equipment-grid');
    if (!equipmentGrid) return;

    equipmentGrid.innerHTML = '';

    if (!equipment || equipment.length === 0) {
        equipmentGrid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 40px;">
                <i class="fas fa-search" style="font-size: 3rem; color: #ccc; margin-bottom: 20px;"></i>
                <h3>No equipment found</h3>
                <p>Try adjusting your search criteria or check back later for new listings.</p>
            </div>
        `;
        return;
    }

    equipment.forEach(item => {
        const card = createEquipmentCard(item);
        equipmentGrid.appendChild(card);
    });
}

function createEquipmentCard(item) {
    const card = document.createElement('div');
    card.className = 'equipment-card';
    card.addEventListener('click', () => showEquipmentDetail(item));

    const icon = getCategoryIcon(item.category);
    const priceDisplay = item.dailyRate ? `$${item.dailyRate}/day` : 'Contact for pricing';
    
    card.innerHTML = `
        <div class="equipment-image">
            <i class="${icon}"></i>
        </div>
        <div class="equipment-info">
            <h3 class="equipment-title">${item.title}</h3>
            <p class="equipment-description">${item.description || 'No description available'}</p>
            <div class="equipment-details">
                <span class="equipment-price">${priceDisplay}</span>
                <span class="equipment-location">
                    <i class="fas fa-map-marker-alt"></i> ${item.location}
                </span>
            </div>
            <div class="equipment-owner">
                <i class="fas fa-user"></i>
                <span>${item.firstName} ${item.lastName}</span>
                <span class="equipment-category">${item.category}</span>
            </div>
        </div>
    `;

    return card;
}

function getCategoryIcon(category) {
    const icons = {
        'Grooming': 'fas fa-cut',
        'Training': 'fas fa-graduation-cap',
        'Health': 'fas fa-heartbeat',
        'Travel': 'fas fa-car',
        'Safety': 'fas fa-shield-alt'
    };
    return icons[category] || 'fas fa-paw';
}

function showEquipmentDetail(equipment) {
    const modal = document.getElementById('equipment-modal');
    const detailContainer = document.getElementById('equipment-detail');
    
    currentEquipment = equipment;
    
    const icon = getCategoryIcon(equipment.category);
    const availabilityBadge = equipment.available ? 
        '<span style="color: #28a745; font-weight: bold;">Available</span>' : 
        '<span style="color: #dc3545; font-weight: bold;">Not Available</span>';

    detailContainer.innerHTML = `
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; align-items: start;">
            <div>
                <div style="height: 300px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px; display: flex; align-items: center; justify-content: center; color: white; font-size: 4rem; margin-bottom: 20px;">
                    <i class="${icon}"></i>
                </div>
                <div style="background: #f8f9fa; padding: 20px; border-radius: 10px;">
                    <h4>Rental Information</h4>
                    <div style="margin-top: 15px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span>Daily Rate:</span>
                            <strong>$${equipment.dailyRate}/day</strong>
                        </div>
                        ${equipment.weeklyRate ? `
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span>Weekly Rate:</span>
                            <strong>$${equipment.weeklyRate}/week</strong>
                        </div>
                        ` : ''}
                        ${equipment.monthlyRate ? `
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span>Monthly Rate:</span>
                            <strong>$${equipment.monthlyRate}/month</strong>
                        </div>
                        ` : ''}
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span>Deposit:</span>
                            <strong>$${equipment.deposit || 0}</strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span>Location:</span>
                            <strong>${equipment.location}</strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span>Pickup:</span>
                            <strong>${equipment.pickupMethod}</strong>
                        </div>
                        ${equipment.deliveryFee ? `
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span>Delivery Fee:</span>
                            <strong>$${equipment.deliveryFee}</strong>
                        </div>
                        ` : ''}
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span>Status:</span>
                            <strong>${availabilityBadge}</strong>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <h2 style="margin-bottom: 15px;">${equipment.title}</h2>
                <div style="margin-bottom: 20px;">
                    <span class="equipment-category" style="margin-right: 10px;">${equipment.category}</span>
                    ${equipment.subcategory ? `<span class="equipment-category">${equipment.subcategory}</span>` : ''}
                </div>
                <p style="line-height: 1.6; margin-bottom: 20px; color: #666;">${equipment.description || 'No description available'}</p>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                    <h4>Owner Information</h4>
                    <p style="margin-bottom: 10px;"><strong>${equipment.firstName} ${equipment.lastName}</strong></p>
                    <p style="color: #666; margin-bottom: 15px;">${equipment.bio || 'No bio available'}</p>
                    <div style="display: flex; align-items: center; gap: 10px; color: #666;">
                        <i class="fas fa-star" style="color: #ffc107;"></i>
                        <span>4.8/5 (24 reviews)</span>
                    </div>
                </div>

                ${equipment.available ? `
                <div style="text-align: center;">
                    <button class="btn btn-primary" onclick="openBookingModal()" style="width: 100%; margin-bottom: 10px;">
                        <i class="fas fa-calendar-plus"></i> Book This Equipment
                    </button>
                    <button class="btn btn-secondary" onclick="contactOwner()" style="width: 100%;">
                        <i class="fas fa-envelope"></i> Contact Owner
                    </button>
                </div>
                ` : `
                <div style="text-align: center; padding: 20px; background: #f8d7da; color: #721c24; border-radius: 10px;">
                    <i class="fas fa-exclamation-triangle" style="margin-bottom: 10px;"></i>
                    <p>This equipment is currently not available for rent.</p>
                </div>
                `}
            </div>
        </div>
    `;
    
    modal.style.display = 'block';
}

function openBookingModal() {
    if (!currentUser) {
        showMessage('Please login to book equipment', 'error');
        document.getElementById('login-modal').style.display = 'block';
        return;
    }

    if (currentUser.id === currentEquipment.ownerId) {
        showMessage('You cannot rent your own equipment', 'error');
        return;
    }

    const modal = document.getElementById('booking-modal');
    currentBookingEquipment = currentEquipment;
    
    // Set minimum date to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('booking-start').min = today;
    document.getElementById('booking-end').min = today;
    
    modal.style.display = 'block';
    updateBookingSummary();
}

function updateBookingSummary() {
    const startDate = document.getElementById('booking-start').value;
    const endDate = document.getElementById('booking-end').value;
    const summaryContainer = document.getElementById('booking-summary');

    if (!startDate || !endDate || !currentBookingEquipment) {
        summaryContainer.innerHTML = '<p>Please select your rental dates to see pricing.</p>';
        return;
    }

    const start = new Date(startDate);
    const end = new Date(endDate);
    const totalDays = Math.ceil((end - start) / (1000 * 60 * 60 * 24)) + 1;

    if (totalDays <= 0) {
        summaryContainer.innerHTML = '<p style="color: #dc3545;">End date must be after start date.</p>';
        return;
    }

    const rentalAmount = currentBookingEquipment.dailyRate * totalDays;
    const deliveryFee = document.getElementById('booking-pickup').value === 'delivery' ? (currentBookingEquipment.deliveryFee || 0) : 0;
    const deposit = currentBookingEquipment.deposit || 0;
    const total = rentalAmount + deliveryFee + deposit;

    summaryContainer.innerHTML = `
        <h4>Booking Summary</h4>
        <div class="summary-item">
            <span>Equipment:</span>
            <span>${currentBookingEquipment.title}</span>
        </div>
        <div class="summary-item">
            <span>Rental Period:</span>
            <span>${totalDays} day${totalDays > 1 ? 's' : ''}</span>
        </div>
        <div class="summary-item">
            <span>Daily Rate:</span>
            <span>$${currentBookingEquipment.dailyRate}/day</span>
        </div>
        <div class="summary-item">
            <span>Rental Amount:</span>
            <span>$${rentalAmount}</span>
        </div>
        ${deliveryFee > 0 ? `
        <div class="summary-item">
            <span>Delivery Fee:</span>
            <span>$${deliveryFee}</span>
        </div>
        ` : ''}
        <div class="summary-item">
            <span>Security Deposit:</span>
            <span>$${deposit}</span>
        </div>
        <div class="summary-item">
            <span>Total Amount:</span>
            <span>$${total}</span>
        </div>
    `;
}

function contactOwner() {
    if (!currentUser) {
        showMessage('Please login to contact the owner', 'error');
        return;
    }

    // For MVP, just show a message
    showMessage('Contact feature will be available soon. Please use booking to communicate with the owner.', 'info');
}

async function handleBooking(e) {
    e.preventDefault();
    
    const startDate = document.getElementById('booking-start').value;
    const endDate = document.getElementById('booking-end').value;
    const pickupMethod = document.getElementById('booking-pickup').value;
    const message = document.getElementById('booking-message').value;

    if (!startDate || !endDate) {
        showMessage('Please select start and end dates', 'error');
        return;
    }

    try {
        const response = await apiRequest('/api/bookings', {
            method: 'POST',
            body: JSON.stringify({
                equipmentId: currentBookingEquipment.id,
                startDate,
                endDate,
                pickupMethod,
                message
            })
        });

        document.getElementById('booking-modal').style.display = 'none';
        showMessage('Booking request sent successfully! The owner will review and respond within 24 hours.', 'success');
        
        // Clear form
        document.getElementById('booking-form').reset();
    } catch (error) {
        // Error already shown in apiRequest
    }
}

// Search and Filter Functions
function performSearch() {
    loadEquipment();
}

function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
    }
}

// Message System
function showMessage(message, type = 'info') {
    const container = document.getElementById('message-container');
    if (!container) return;

    const messageEl = document.createElement('div');
    messageEl.className = `message ${type}`;
    messageEl.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
            <i class="fas fa-${getMessageIcon(type)}"></i>
            <span>${message}</span>
            <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; color: inherit; margin-left: auto; cursor: pointer;">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;

    container.appendChild(messageEl);

    // Auto remove after 5 seconds
    setTimeout(() => {
        if (messageEl.parentNode) {
            messageEl.remove();
        }
    }, 5000);
}

function getMessageIcon(type) {
    const icons = {
        'success': 'check-circle',
        'error': 'exclamation-circle',
        'info': 'info-circle',
        'warning': 'exclamation-triangle'
    };
    return icons[type] || 'info-circle';
}

// Update booking summary when dates change
document.addEventListener('change', function(e) {
    if (e.target.id === 'booking-start' || e.target.id === 'booking-end' || e.target.id === 'booking-pickup') {
        updateBookingSummary();
    }
});

// Smooth scrolling for navigation links
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('nav-link') && e.target.getAttribute('href')?.startsWith('#')) {
        e.preventDefault();
        const targetId = e.target.getAttribute('href').substring(1);
        scrollToSection(targetId);
    }
});